import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Get all players
export async function GET() {
  try {
    const players = await sql`
      SELECT id, name, jersey_number, price, position, photo_url
      FROM players
      ORDER BY price ASC
    `;
    return Response.json({ players });
  } catch (error) {
    console.error("Error fetching players:", error);
    return Response.json({ error: "Failed to fetch players" }, { status: 500 });
  }
}

// Create a new player (admin only)
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Admin check
    const userRows =
      await sql`SELECT role FROM auth_users WHERE id = ${session.user.id}`;
    if (!userRows[0] || userRows[0].role !== "admin") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const { name, jersey_number, price, position, photo_url } =
      await request.json();

    if (!name || !price) {
      return Response.json(
        { error: "Name and price are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO players (name, jersey_number, price, position, photo_url)
      VALUES (${name}, ${jersey_number || null}, ${price}, ${position || null}, ${photo_url || null})
      RETURNING *
    `;

    return Response.json({ player: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating player:", error);
    return Response.json({ error: "Failed to create player" }, { status: 500 });
  }
}
